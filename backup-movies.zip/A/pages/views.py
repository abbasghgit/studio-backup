from django.shortcuts import render ,redirect
from django.contrib import messages
from django.views import View
from .models import Contact ,Faq ,About ,Law

from .forms import ContactForm
#
#
# Create your views here.
class ContactView(View):
    form_class = ContactForm
    template_name = 'contact/contact.html'
    def get(self ,request):
        context = {'form':self.form_class}
        return render(request ,self.template_name ,context)
    def post(self ,requset):
        form = self.form_class(requset.POST)
        if form.is_valid():
            cd = form.cleaned_data
            new_post = form.save(commit=False)
            new_post.first_name = cd['first_name']
            new_post.last_name = cd['last_name']
            new_post.phone_number = cd['phone_number']
            new_post.email = cd['email']
            new_post.body = cd['body']
            new_post.save()
            messages.success(requset ,'پیام شما با موفقیت پست شد' ,'success')
        return redirect('pages:contact')
#
# 
#     
class FaqView(View):
    template_name = 'contact/faq.html'
    def get(self ,request):
        faq = Faq.objects.order_by('create')[:10]
        context = {
            'faq':faq,
        }
        return render(request ,self.template_name ,context)
#
#
#
class AboutUsView(View):
    template_name = 'contact/about_us.html'
    def get(self ,request):
        about = About.objects.order_by('role').all()
        context = {'users':about}
        return render(request ,self.template_name ,context)
    

class PrivacyPolicyView(View):
    template_name = 'contact/privacy-policy.html'
    def get(self ,request):
        privacy = Law.objects.order_by('num').all()
        context = {'privacy_policy':privacy}
        return render(request ,self.template_name ,context)
    