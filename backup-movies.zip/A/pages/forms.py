from django import forms
from .models import Contact


class ContactForm(forms.ModelForm):
    email = forms.CharField(
      label='',
      required = True,
      max_length = 155,
      widget=forms.EmailInput(attrs={
        
         "placeholder":"ایمیل شما",
      })
   )
    first_name = forms.CharField(
      label='',
      required = True,
      max_length = 155,
      widget=forms.TextInput(attrs={
        
         "placeholder":"نام شما",
      })
   )
    last_name = forms.CharField(
      label='',
      required = True,
      max_length = 155,
      widget=forms.TextInput(attrs={
        
         "placeholder":"نام خانوادگی",
      })
   )
    phone_number = forms.CharField(
      label='',
      required = True,
      max_length = 11,
      widget=forms.TextInput(attrs={
        
         "placeholder":"شماره همراه",
      })
   )
    body = forms.CharField(
        label= '',
        required=True,
        max_length=700,
        widget=forms.Textarea(attrs={
            "placeholder":"پیام شما",
        })
    )
    class Meta:
        model = Contact
        fields = ('first_name' ,'last_name' ,'phone_number' ,'body','email')