from django.db import models
import datetime
# Create your models here.
#
#
class Contact(models.Model):
    first_name = models.CharField(max_length=50)
    last_name = models.CharField(max_length=50)
    phone_number = models.CharField(max_length=11)
    email = models.CharField(max_length=150 ,blank=True ,null=True)
    body = models.TextField(max_length=700)
    create = models.DateTimeField(default=datetime.datetime.today())
    def __str__(self):
        return f'{self.first_name}_{self.last_name} {self.phone_number}'
#
#    
#
class Faq(models.Model):
    title = models.TextField(max_length=650)
    body = models.TextField(max_length=750)
    create = models.DateTimeField(default=datetime.datetime.today())
    availabe = models.BooleanField(default=True)

    def __str__(self):
        return f'{self.title}'
#
#
#
def about_uploade_to(instance ,filename):
    return "contact/about-us/.{0}/{1}".format(instance.name ,filename)    
class About(models.Model):
    ROLES = (
        ('کاربر فعال' , 'کاربر فعال'),
        ('آدمین' , 'آدمین'),
        ('برنامه نویس' , 'برنامه نویس'),
        ('طراح' , 'طراح'),
        ('هنرمند' , 'هنرمند'),
        ('نویسنده' , 'نویسنده'),
    )
    name = models.CharField(max_length=45)
    role = models.CharField(choices=ROLES , max_length=50)
    img = models.ImageField(upload_to=about_uploade_to)

    def __str__(self):
        return f'{self.role} _ {self.name}'
    

class Law(models.Model):
    title = models.TextField(max_length=250)
    body = models.TextField(max_length= 700)
    create = models.DateTimeField(default=datetime.datetime.today())
    num = models.IntegerField(unique=True)
    available = models.BooleanField(default=True)
    
    def __str__(self):
        return f'{self.title}'