from django.urls import path
from .views import *
app_name = 'pages'
urlpatterns = [
    path('' , ContactView.as_view() , name="contact"),
    path('faq/' , FaqView.as_view() , name="faq"),
    path('about/' , AboutUsView.as_view() , name="about_us"),
    path('privacy-policy/' , PrivacyPolicyView.as_view() , name="privacy_policy"),

]