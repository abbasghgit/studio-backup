from .models import Movie#
#
SESSION_KEY = 'LIST'
class List:
    def __init__(self ,request):
        self.session = request.session
#
        mylist = self.session.get(SESSION_KEY)
        if SESSION_KEY not in request.session:
            list = request.session[SESSION_KEY] = {}
#
        self.list = mylist
#
    def __iter__(self):
        movie_ids = self.list.keys()
        movies = Movie.objects.order_by('name').filter(id__in = movie_ids)
        for item in movies:
            self.list[str(item.id)]['movie'] = item
            yield item
#
    def add_list(self ,movie_id):
        if movie_id not in self.list:
            self.list[str(movie_id)] = {}
        self.save()
#
    def save(self):
        self.session.modified = True
#
    def __len__(self):
        return len(self.list.copy())
#
    def remove_item_in_list(self ,movie_id):
        if str(movie_id) in self.list.keys():
            del self.list[str(movie_id)]
        self.save()