from .models import Category ,Gener

def category(request):
    mycate = Category.objects.order_by('name')[:5]
#    mygener = Gener.objects.order_by('name')[:5]
    return {
        'categories':mycate,
#        'geners': mygener,
        }