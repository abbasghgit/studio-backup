from django.urls import path
from .views import *
app_name = 'movie'
urlpatterns = [
    path('movie-details/<int:movie_id>/<slug:movie_slug>/' , MovieDetailsView.as_view() , name="movie_details"),
    path('category-details/<int:category_id>/' , CategoryDetailsView.as_view() , name="category_details"),
    path('like/<int:movie_id>/<slug:movie_slug>/' , LikeView.as_view() , name="like"),
    path('list/' , WatchListView.as_view() , name="list"),
    path('add-list/' ,AddListDefView , name="add_list"),
    path('remove-list/<int:movie_id>' ,RemoveListView.as_view() , name="remove_list"),
]