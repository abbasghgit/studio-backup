from django.shortcuts import render ,redirect ,get_object_or_404
from django.views import View
from django.http import JsonResponse
from django.utils.decorators import method_decorator
from django.contrib.auth.decorators import login_required
from django.contrib.auth.mixins import LoginRequiredMixin
from .models import Movie ,Comment,Vote,Series ,Category,Gener
from .forms import CommentForm
from .watch import List
#? Create your views here.
#?
#?
class MovieDetailsView(View):
    form_class = CommentForm
    template_name = 'movies/movie_details.html'
    def setup(self, request, *args, **kwargs):
        self.movie = get_object_or_404(Movie,id=kwargs['movie_id'] ,slug=kwargs['movie_slug'])
        return super().setup(request, *args, **kwargs)
    def get(self ,request,*args ,**kwargs):
        movie = self.movie
        can_user_like = movie.can_user_like(request.user)
        series = Series.objects.filter(movie=movie)[:1]
        comments = Comment.objects.filter(movie=movie ,is_reply=False).order_by('created').all()
        movie_order_by_category = Movie.objects.filter(category = self.movie.category)
        get_free = False
        if self.movie.available:
            get_free = True
        elif request.user.role == 'vipuser':
            get_free = True
        else:
            get_free = False

        context = {
            'movie':movie,
            'can_user_like': can_user_like,
            'series':series,
            'movie_order_by_category': movie_order_by_category,
            'comments':comments,
            'form':self.form_class,
            'get_free': get_free,
        }
        return render(request , self.template_name ,context)
    @method_decorator(login_required)
    def post(self ,request,*args ,**kwargs):
        user = request.user
        form = self.form_class(request.POST)
        if form.is_valid():
            new_comment = form.save(commit=False)
            new_comment.user = user
            new_comment.movie = self.movie
            new_comment.save()
        return redirect('movie:movie_details' ,self.movie.id ,self.movie.slug)
#
#
#
class CategoryDetailsView(View):
    template_name = 'movies/category.html'
    def get(self ,request,*args ,**kwargs):
        query = None
        if request.GET.get('gener'):
            query = Movie.objects.filter(geners__name = request.GET['gener'])
        
        gener = Gener.objects.order_by('name')[:20]
        category = get_object_or_404(Category,id=kwargs['category_id'])
        slider = Movie.objects.filter(age__gte =12)[:3]
        movie_order_by_year = Movie.objects.filter(category = category,age__gte =12)[:7]
        movie_order_by_imdb = Movie.objects.filter(category = category)[:7]
        movie_order_by_duration = Movie.objects.filter(category = category,duration__gte =182)[:7]
        context = {
            'sliders' :slider,
            'get_query':query,
            'geners' :gener,
            'movie_order_by_year': movie_order_by_year,
            'movie_order_by_duration':movie_order_by_duration,
            'movie_order_by_imdb': movie_order_by_imdb,
        }
        return render(request , self.template_name ,context)
#
#
#
class LikeView(View ,LoginRequiredMixin):
    def setup(self, request, *args, **kwargs):
        self.movie = get_object_or_404(Movie,id=kwargs['movie_id'] ,slug=kwargs['movie_slug'])
        return super().setup(request, *args, **kwargs)
    def get(self ,request ,*args ,**kwargs):
        movie = self.movie
        user = request.user
        try:
            like = Vote.objects.get(user=user ,movie=movie)
            like.delete()
            return redirect('movie:movie_details' ,self.movie.id ,self.movie.slug)
        except:
            Vote.objects.create(movie = self.movie ,user =request.user).save()
            return redirect('movie:movie_details' ,self.movie.id ,self.movie.slug)
#
#        
#
class WatchListView(View):
    template_name = 'movies/watch.html'
    def get(self ,request):
        mylist = List(request)
        context ={
            'list':mylist,
        }
        return render(request ,self.template_name ,context)
    
def AddListDefView(request):
    mylist = List(request)
    if request.POST.get('action') == 'post':
        movie_id = request.POST.get('movie_id')
        mylist.add_list(movie_id=movie_id)
        list_len = mylist.__len__()
        return JsonResponse({'list':str(list_len)})
 
class RemoveListView(View):
    def get(self ,request ,movie_id):
        mylist = List(request)
        mylist.remove_item_in_list(movie_id=movie_id)
        list_len = mylist.__len__()
        return redirect('movie:list')