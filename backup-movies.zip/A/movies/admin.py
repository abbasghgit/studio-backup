from django.contrib import admin
from .models import *
# Register your models here.
admin.site.register(Category)
admin.site.register(Country)
admin.site.register(Gener)
admin.site.register(Movie)
admin.site.register(Video)
admin.site.register(Part)
admin.site.register(Season)
admin.site.register(Series)
admin.site.register(Comment)
admin.site.register(Vote)
admin.site.register(Poster)
admin.site.register(Trailer)