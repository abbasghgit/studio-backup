from django import forms
from .models import Comment
class CommentForm(forms.ModelForm):
    body = forms.CharField(
        label= '',
        required=True,
        max_length=300,
        widget=forms.Textarea(attrs={
            "placeholder":"دیدگاه شما",
        })
    )
    class Meta:
        model = Comment
        fields = ('body',)