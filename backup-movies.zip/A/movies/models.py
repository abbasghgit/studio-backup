from django.db import models
from django.urls import reverse
from django.utils.text import slugify
from accounts.models import CustomUser
import datetime
# Create your models here.
class Category(models.Model):
    title = models.CharField(max_length=50 ,verbose_name=' نام دسته بندی به انگلیسی')
    name = models.CharField(max_length=50 ,verbose_name='نام دسته بندی')
    slug = models.SlugField(max_length=70,blank=True,null=True)
    category = models.ForeignKey(
        'self',
        on_delete=models.SET_NULL,
        related_name='categories',
        null=True,
        blank=True,
        )
    def __str__(self):
        return self.name
#
    def save(self, *args ,**kwargs):
        if self.slug is None:
            self.slug = slugify(self.title)
        return super().save(*args ,**kwargs)
#
#
#
class Gener(models.Model):
    name = models.CharField(max_length=70,verbose_name='ژانر')
    def __str__(self):
        return self.name
#
class Contact(models.Model):
    name = models.CharField(max_length=70,verbose_name='مخاطب')
    def __str__(self):
        return self.name
#
class Country(models.Model):
    name = models.CharField(max_length=70,verbose_name='کشور')
    def __str__(self):
        return self.name
#
def upload_poster_images(instance ,filename):
    return 'images/movie/posters/{0}/{1}'.format(instance.name ,filename)
#
class Poster(models.Model):
    name = models.CharField(max_length=70,verbose_name='نام فیلم')
    image = models.ImageField(upload_to=upload_poster_images)
#
    def __str__(self):
        return self.name
#
def upload_poser_img(instance,filename):
    return 'images/movie/posters/{0}/{1}'.format(instance.name ,filename)
#
def upload_poster_trailers(instance ,filename):
    return 'images/movie/trailers/{0}/{1}'.format(instance.name ,filename)
#
class Trailer(models.Model):
    name = models.CharField(max_length=70,verbose_name='نام فیلم')
    duration = models.IntegerField(verbose_name='مدت زمان تریلر',blank=True,null=True)
    descriptions = models.TextField(max_length=700 ,verbose_name='توضیحات',blank=True,null=True)

    trailer = models.FileField(upload_to=upload_poster_trailers)
#
    def __str__(self):
        return self.name
def upload_trailer_video(instance,filename):
    return 'images/movie/trailers/{0}/{1}'.format(instance.name ,filename)
#
class Movie(models.Model):
    title = models.CharField(max_length=70,verbose_name='تیتر فیلم به لاتین')
    name = models.CharField(max_length=70,verbose_name='نام فیلم')
    slug = models.SlugField(max_length=70,blank=True,null=True)
    year = models.IntegerField(verbose_name='سال تولید')
    age = models.IntegerField(verbose_name='حد اقل سن مجاز')
    duration = models.IntegerField(verbose_name='مدت زمان فیلم')
    poster = models.ImageField(upload_to=upload_poser_img ,verbose_name='پوستر')
    imdb_rating = models.FloatField(verbose_name='امتیاز')
    trailer = models.FileField(upload_to=upload_trailer_video,verbose_name= 'تریلر',null=True,blank=True)
    trailer_link = models.CharField(max_length=500 ,verbose_name= 'لینک تریلر',null=True,blank=True)
    descriptions = models.TextField(max_length=700 ,verbose_name='توضیحات')
    category = models.ForeignKey(
        Category,
        on_delete=models.SET_NULL,
        related_name='movies',
        null=True,
        blank=True,
    )
    geners = models.ManyToManyField(Gener,verbose_name="ژانرها")
    images = models.ManyToManyField(Poster,verbose_name='پوسترها',blank=True)
    trailers = models.ManyToManyField(Trailer,verbose_name='تریلر ها',blank=True)
    country = models.ManyToManyField(Country,verbose_name='کشورها')
    contact = models.ManyToManyField(Contact,verbose_name='مخاطبان',blank=True)
    dirctore = models.CharField(max_length=80,verbose_name='کارگردان',null=True,blank=True)
    players = models.CharField(max_length=70,verbose_name='بازیگران',null=True,blank=True)
    available = models.BooleanField(default=True ,verbose_name='رایگان')
#
    def __str__(self):
        return self.name
#
    def save(self, *args ,**kwargs):
        if self.slug is None:
            self.slug = slugify(self.title)
        return super().save(*args ,**kwargs)
#
    def get_absolute_url(self, *args ,**kwargs):
        return reverse('movie:movie_details' ,args=(self.id ,self.slug))
#
    def user_like(self):
        count = self.mvotes.count()
        return count
#
    def can_user_like(self ,user):
        user = user.uvotes.filter(movie=self)
        if user.exists():
            return True
        return False
#
#
#
def upload_part_of_videos(instance,filename):
    return 'images/movie/videos/{0}/{1}'.format(instance.name ,filename)
#
class Video(models.Model):
    QUALITY = (
        ('140p' ,'140p'),
        ('240p' ,'240p'),
        ('360p' , '360p'),
        ('480p' , '480p'),
        ('720p' , '720p'),
        ('1080p' , '1080p'),
    )
    name = models.CharField(max_length=70,verbose_name='نام فیلم')
    part = models.IntegerField(verbose_name='شماره قسمت')
    season = models.IntegerField(verbose_name='شماره فصل')
    quality = models.CharField(choices=QUALITY ,max_length=50,verbose_name='کیفیت')
    video = models.FileField(upload_to=upload_part_of_videos ,verbose_name='ویدیو')
#
    def __str__(self):
        return f'نام :{self.name} - فصل:{self.season} - قسمت:{self.part} - کیفیت:{self.quality}'
#
class Part(models.Model):
    name = models.CharField(max_length=70,verbose_name='نام فیلم')
    part = models.IntegerField(verbose_name='شماره قسمت')
    season = models.IntegerField(verbose_name='شماره فصل')
    videos = models.ManyToManyField(
        Video ,
        verbose_name='انتخاب ویدیو',
        related_name='videos',
        )
    video_link = models.CharField(max_length=500,verbose_name='لینک ویدیو',null=True,blank=True)
#
    def __str__(self):
        return f'نام :{self.name} - فصل:{self.season} - قسمت:{self.part}'
#
#
class Season(models.Model):
    name = models.CharField(max_length=70,verbose_name='نام فیلم')
    season = models.IntegerField(verbose_name='شماره فصل')
    parts = models.ManyToManyField(
        Part ,
        verbose_name='انتخاب قسمت ها',
        related_name='parts',
        )
#
    def __str__(self):
        return f'نام :{self.name} - فصل:{self.season}'
#
#
class Series(models.Model):
    name = models.CharField(max_length=70 ,verbose_name='نام فیلم')
    movie = models.OneToOneField(
        Movie,
        on_delete=models.CASCADE,
        verbose_name='انتخاب فیلم',
        related_name='series',
    )
    seasons = models.ManyToManyField(Season)
#
    def __str__(self):
        return f'نام :{self.name} - فیلم:{self.movie.name}'
#
#
#
#
#
#
class Vote(models.Model):
    user = models.ForeignKey(
        CustomUser,
        on_delete=models.SET_NULL,
        related_name='uvotes',
        null=True,
        blank=True,
    )
    movie = models.ForeignKey(
        Movie,
        on_delete=models.CASCADE,
        related_name='mvotes',
    )
    def __str__(self):
      return f'{self.user} liked {self.movie}'
#
#
class Comment(models.Model):
    user = models.ForeignKey(
        CustomUser,
        on_delete=models.SET_NULL,
        related_name='ucomments',
        null=True,
        blank=True,
        verbose_name='نام کاربر'
    )
    movie = models.ForeignKey(
        Movie,
        on_delete=models.CASCADE,
        related_name='mcomments',
        verbose_name='نام فیلم'
    )
    reply = models.ForeignKey(
        'self',
        on_delete=models.CASCADE,
        related_name='mcomments',
        verbose_name='پاسخ به کامنت',
        blank=True,
        null=True,
    )
    body = models.TextField(max_length=400 ,verbose_name='دیدگاه')
    is_reply = models.BooleanField(default=False,verbose_name='پاسخ')
    available = models.BooleanField(default = False,verbose_name='مجاز بودن')
    created = models.DateTimeField(default = datetime.datetime.today(),verbose_name='زمان ساخت')
#
    def __str__(self):
      return f'{self.movie} - {self.user} - {self.is_reply}'
#
#
#