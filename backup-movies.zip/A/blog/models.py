from django.db import models
from accounts.models import CustomUser
from django.urls import reverse
from movies.models import Gener ,Category ,Movie ,Country
import datetime
# Create your models here.
def upload_poster_img(instance,filename):
    return 'images/movie/posters/{0}/{1}'.format(instance.title ,filename)
#
class Article(models.Model):
    user = models.ForeignKey(
        CustomUser ,
        on_delete= models.SET_NULL,
        related_name='articles',
        verbose_name='کاربر',
        blank=True,
        null=True,
    )
    movie = models.ForeignKey(
        Movie ,
        on_delete= models.SET_NULL,
        related_name='articles',
        verbose_name='فیلم',
        blank=True,
        null=True,
    )
    category = models.ForeignKey(
        Category ,
        on_delete= models.SET_NULL,
        related_name='article_categories',
        verbose_name='دسته بندی',
        blank=True,
        null=True,
    )
    title = models.CharField(max_length=70,verbose_name='تیتر فیلم به لاتین')
    poster = models.ImageField(upload_to=upload_poster_img ,verbose_name='پوستر')
    summery = models.TextField(max_length=700 ,verbose_name='داستان')
    hint = models.TextField(max_length=250 ,verbose_name='نکته ها')
    descriptions = models.TextField(max_length=350 ,verbose_name='توضیحات')
    geners = models.ManyToManyField(Gener,related_name='geners' ,verbose_name="ژانرها")
    country = models.ManyToManyField(Country,verbose_name='کشورها')
    available = models.BooleanField(default=True ,verbose_name='دسترسی')
    create = models.DateTimeField(default=datetime.datetime.today() ,verbose_name='تاریخ')
    
    def get_absolute_url(self ,*args ,**kwargs):
        return reverse('blog:article_details' ,args=(self.id,))
    def __str__(self):
        return f'{self.user.username} - {self.title}'
#
#
#
class ArticleComment(models.Model):
    user = models.ForeignKey(
        CustomUser,
        on_delete=models.SET_NULL,
        related_name='user_comments',
        null=True,
        blank=True,
        verbose_name='نام کاربر'
    )
    article= models.ForeignKey(
        Article,
        on_delete=models.SET_NULL,
        related_name='article_comments',
        verbose_name='نام مقاله',
        blank=True,
        null=True,
    )
    reply = models.ForeignKey(
        'self',
        on_delete=models.CASCADE,
        related_name='mcomments',
        verbose_name='پاسخ به کامنت',
        blank=True,
        null=True,
    )
    body = models.TextField(max_length=400 ,verbose_name='دیدگاه')
    is_reply = models.BooleanField(default=False,verbose_name='پاسخ')
    available = models.BooleanField(default = False,verbose_name='مجاز بودن')
    created = models.DateTimeField(default = datetime.datetime.today(),verbose_name='زمان ساخت')
#
    def __str__(self):
      return f'{self.article} - {self.user} - {self.is_reply}'
#
#
#