from django.urls import path
from .views import *
app_name = 'blog'
urlpatterns = [
    path('article/' ,ArticleView.as_view() ,name='article'),
    path('article-details/<int:article_id>/' ,ArticleDetailsView.as_view() ,name='article_details'),
]