from django import forms
from .models import ArticleComment
class ArticleCommentForm(forms.ModelForm):
    body = forms.CharField(
        label= '',
        required=True,
        max_length=330,
        widget=forms.Textarea(attrs={
            "placeholder":"دیدگاه شما",
        })
    )
    class Meta:
        model = ArticleComment
        fields = ('body',)