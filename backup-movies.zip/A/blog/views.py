from django.shortcuts import render,redirect ,get_object_or_404
from django.core.paginator import Paginator
from django.views import View
from django.utils.decorators import method_decorator
from django.contrib.auth.decorators import login_required
from .models import Article
from .forms import ArticleCommentForm
# Create your views here.
class ArticleView(View):
    template_name = 'blog/article.html'
    def get(self ,request):
        article = Article.objects.all()
        paginator = Paginator(article , 10)
        paget_number = request.GET.get('page')
        page_obj = paginator.get_page(paget_number)
        recent = Article.objects.order_by('create')[:7]
        search = None
        if request.GET.get('search'):
            search = Article.objects.order_by('create').filter(title__contains =request.GET['search'])[:9]
        context = {
            'page_obj': page_obj,
            'recent': recent,
            'search': search,
        }
        return render(request ,self.template_name ,context)

class ArticleDetailsView(View):
    template_name = 'blog/article_details.html'
    form_class = ArticleCommentForm
    def setup(self, request, *args, **kwargs):
        self.article = get_object_or_404(Article ,id=kwargs['article_id'])
        
        return super().setup(request, *args, **kwargs)
    def get(self ,request, *args, **kwargs):
        article = self.article
        recent = Article.objects.order_by('create')[:7]
        search = None
        if request.GET.get('search'):
            search = Article.objects.order_by('create').filter(title__contains =request.GET['search'])[:9]
        context = {
            'article': article,
            'form': self.form_class,
            'search': search,
            'recent': recent,
        }
        return render(request ,self.template_name ,context)
    @method_decorator(login_required)
    def post(self ,request,*args ,**kwargs):
        user = request.user
        article = self.article
        form = self.form_class(request.POST)
        if form.is_valid():
            new_comment = form.save(commit=False)
            new_comment.user = user
            new_comment.article = article
            new_comment.save()
        return redirect('blog:article_details' ,self.article.id)