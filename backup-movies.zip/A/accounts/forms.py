from django import forms
from django.contrib.auth.forms import UserChangeForm ,UserCreationForm
from django.contrib.auth import get_user_model
from django.core.exceptions import ValidationError
from .models import CustomUserProfile
USER = get_user_model()
#
#
#
class CodeChangeForm(forms.Form):
    code1 = forms.CharField(
      label='',
      required = True,
      max_length = 155,
      widget=forms.TextInput(attrs={
         "placeholder":" کد تأیید ایمیل قبلی را وارد کنید",
      })
   )
    code2 = forms.CharField(
      label='',
      required = True,
      max_length = 155,
      widget=forms.TextInput(attrs={
         "placeholder":" کد تأیید ایمیل جدید را وارد کنید",
      })
   )
#
#
#
class ChangeEmailForm(forms.ModelForm):
   email = forms.CharField(
      label='',
      required = True,
      max_length = 155,
      widget=forms.EmailInput(attrs={
        
         "placeholder":"ایمیل را وارد کنید",
      })
   )   
   class Meta:
      model = USER
      fields = ('email',)

   def clean_email(self):
      email = self.cleaned_data['email']
      user = USER.objects.filter(email=email).exists()
      if user:
         raise ValidationError(' ایمیل وجود دارد دوباره امتحان کنید')
      return email
#
#
#
class ProfileSettingForm(forms.ModelForm):
   biography = forms.CharField(
      label='درباره',
      required = False,
      max_length = 355,
      widget=forms.Textarea(attrs={
         "placeholder":"شرح حال ",
         "class":"",
      })
   )
   address = forms.CharField(
      label='آدرس',
      required = False,
      max_length = 355,
      widget=forms.Textarea(attrs={
         "placeholder":"آدرس خود را وارد کنید",
         "class":"",
      })
   )
   class Meta:
      model = CustomUserProfile
      fields= ('biography' ,'address')
#
#
#
class ProfileForm(forms.ModelForm):
   LANGUAGE = {
        ('پارسی' , 'پارسی'),
        ('english' , 'انگلیسی'),
    }
   SEX = {
        ('زن' , 'female'),
        ('مرد' , 'male'),
        ('خنثی' , 'trans'),
   }
   first_name = forms.CharField(
      label='اسم',
      required = True,
      max_length = 155,
      widget=forms.TextInput(attrs={
         "placeholder":"نام خود را وارد کنید",
         "class":"",
      })
   )
   age = forms.IntegerField(
      label='سال',
      required = False,
      widget=forms.NumberInput(attrs={
         "placeholder":"سن خود را وارد کنید",
          "class":"",
      })
   )
   user_photo = forms.ImageField(
      label='',
      required = False,
      widget=forms.FileInput(attrs={
         "helptext":"عکس خود را انتخاب کنید",
         "class":'file-upload',
         "placeholder":"عکس خود را انتخاب کنید",
      })
   )
   language = forms.ChoiceField(
      choices=LANGUAGE,
      required = False,
      widget=forms.Select(attrs={
         "class":"form-control",
         "style":"background-color: black; color: white; border: 1px solid #404043;",
      })
   )
   sex = forms.ChoiceField(
      choices=SEX,
      required = False,
      widget=forms.Select(attrs={
         "class":"form-control",
         "style":"background-color: black; color: white; border: 1px solid #404043;",
      })
   ) 
   class Meta:
      model = CustomUserProfile
      fields = ('language' ,'age' ,'user_photo','sex')
#
#
#
class CodeForm(forms.Form):
    code = forms.CharField(
      label='',
      required = True,
      max_length = 155,
      widget=forms.TextInput(attrs={
         "placeholder":" کد تأیید را وارد کنید",
      })
   )
#   
#
#
class LoginForm(forms.Form):
   email = forms.CharField(
      label='',
      required = True,
      max_length = 155,
      widget=forms.EmailInput(attrs={
        
         "placeholder":"ایمیل را وارد کنید",
      })
   )
   password = forms.CharField(
      label='',
      required = True,
      max_length = 155,
      widget=forms.PasswordInput(attrs={
        
         "placeholder":"کلمه عبور",
      })
   )
#
#
#
class CustomUserSignUpForm(forms.Form):
   username = forms.CharField(
      label='',
      required = True,
      max_length = 155,
      widget=forms.TextInput(attrs={
         "placeholder":"نام کامل را وارد کنید",
      })
   )
   email = forms.CharField(
      label='',
      required = True,
      max_length = 155,
      widget=forms.EmailInput(attrs={
        
         "placeholder":"ایمیل را وارد کنید",
      })
   )
   first_name = forms.CharField(
      label='',
      required = True,
      max_length = 155,
      widget=forms.TextInput(attrs={
        
         "placeholder":"نام کوچک",
      })
   )
   last_name = forms.CharField(
      label='',
      required = True,
      max_length = 155,
      widget=forms.TextInput(attrs={
        
         "placeholder":"نام خانوادگی",
      })
   )
   password = forms.CharField(
      label='',
      required = True,
      max_length = 155,
      widget=forms.PasswordInput(attrs={
        
         "placeholder":"کلمه عبور",
      })
   )
   class Meta:
      model = USER
      fields = ('username','first_name','last_name' ,'email' ,'password')
   def clean_username(self):
      username = self.cleaned_data['username']
      user = USER.objects.filter(username=username).exists()
      if user:
         raise ValidationError('نام کاربری وجود دارد دوباره امتحان کنید')
      return username
   def clean_email(self):
      email = self.cleaned_data['email']
      user = USER.objects.filter(email=email).exists()
      if user:
         raise ValidationError('ایمیل وجود دارد دوباره امتحان کنید')
      return email
#
#
#
class CustomUserCreationForm(UserCreationForm):
    class Meta(UserCreationForm):
        model = USER
        fields = '__all__'
#
#
#
class CustomUserChangeForm(UserChangeForm):
    class Meta():
        model = USER
        fields = '__all__'
#
#
#
