from django.contrib import admin
from .models import *
from django.contrib.auth.admin import UserAdmin
from .forms import CustomUserChangeForm ,CustomUserCreationForm
USER = CustomUser
#
#
#
class UserProfileInline(admin.StackedInline):
    model = CustomUserProfile
    max_num = 1
    can_delete = False
#
#
#
class UserAdmin(UserAdmin):
    inlines = [UserProfileInline]
#
#
#
class CustomUserAdmin(UserAdmin):
    add_form = CustomUserCreationForm
    form = CustomUserChangeForm
    list_display = ['username' ,'role','is_active' ,'is_staff']
    lits_filter = ['username', 'role' ,'is_active' ,'is_staff']    
    fieldsets = (
      (None,{'fields':('username' ,'email','first_name' ,)}),
      ('permissions',{'fields':('role' ,'is_active','is_staff')})
    )
    add_fieldsets = (
      (None,{'fields':('username' ,'email','first_name', 'role' ,'password1' ,'password2' ,'is_active' ,'is_staff')}),
    )

# Register your models here.
    search_fields = ('username',)
    ordering = ('username',)
#
# 
#   
admin.site.register(USER,CustomUserAdmin)
admin.site.register(CustomUserProfile)
admin.site.register(EmailOtp)
#
#
#permissions
admin.site.register(Module)
admin.site.register(Permission)
admin.site.register(Role)
admin.site.register(UserRole)
