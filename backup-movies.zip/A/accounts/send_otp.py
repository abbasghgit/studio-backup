from django.core.mail import send_mail

def email(email ,code):
    send_mail(
        'فسا استودیو',
        f'کد تایید شما:{code}',
        'abbas123ghavas456@gmail.com',
        [f'{email}'],
        fail_silently =False,
    )