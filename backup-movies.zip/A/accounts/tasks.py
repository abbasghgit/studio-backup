from .models import EmailOtp
import datetime

import time

def my_task():
    t1 = datetime.datetime.today()
    t2 = datetime.timedelta(minutes=2)
    expired_time = t1 - t2
    EmailOtp.objects.filter(create__lt=expired_time).delete()
    print(expired_time)
    print ("""
 ....................................................\n
 ....................................................\n\n
                    
           otp_code deleted successfully\n

 .....................................................\n
 .....................................................\n        
           
""")