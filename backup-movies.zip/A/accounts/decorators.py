from django.shortcuts import render
from functools import wraps
from django.http import HttpResponseForbidden
from .models import UserRole

def get_user_role(user):
    user_role = UserRole.objects.get(user__id = user.id)
    return user_role.role

def has_permission(perm_name):
    def decorator(view_fun):
        @wraps(view_fun)
        def _warpped_view(request ,*args ,**kwargs):
            if request.user.is_authenticated:
                user_role = get_user_role(request.user)
                if user_role and user_role.permissions.filter(name = perm_name).exists():
                    return view_fun(request ,*args ,**kwargs)
#            return render(request ,'accounts/sign_up.html')  
            return HttpResponseForbidden('شما به این بخش دسترسی ندارید')
        return _warpped_view
    return decorator