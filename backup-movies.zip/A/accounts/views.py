from django.shortcuts import render ,redirect
from django.views import View
from django.urls import reverse_lazy
from django.contrib.auth import login ,logout,authenticate
from django.contrib.auth.mixins import LoginRequiredMixin
from django.contrib.auth import views as auth_views
from .forms import CustomUserSignUpForm ,CodeForm ,LoginForm ,ProfileForm ,ProfileSettingForm ,ChangeEmailForm,CodeChangeForm
from .send_otp import email
from .models import *
from django.contrib import messages
import random
from django_q.tasks import async_task
from .tasks import my_task
import time
# Create your views here.
#
#
class SignUpView(View):
    form_class = CustomUserSignUpForm
    template_name = 'accounts/sign_up.html'
    def dispatch(self, request, *args, **kwargs):
        if request.user.is_authenticated:
            messages.success(request ,'شما قبلا وارد حساب خود شدید' ,'info')
            return redirect('home:index')
        return super().dispatch(request, *args, **kwargs)
    def get(self ,request):
        context ={'form':CustomUserSignUpForm}
        return render(request ,self.template_name ,context)
    
    def post(self ,request):
        form = self.form_class(request.POST)
        if form.is_valid():
            cd = form.cleaned_data
            request.session['sign_up'] = {
                'username': cd['username'],
                'email': cd['email'],
                'first_name': cd['first_name'],
                'last_name': cd['last_name'],
                'password': cd['password'],
            }
            return redirect('accounts:send_code')
        context ={'form':CustomUserSignUpForm}
        return render(request ,self.template_name ,context)
#
#
#
def SendCode(request):
    session = request.session['sign_up']
    email_code = session['email']
    otp = EmailOtp.objects.filter(email = email)
    async_task(my_task)
    time.sleep(2)
    try:
        otp_code= EmailOtp.objects.get(email = email_code)
        messages.success(request ,'کد تایید قبلا برای شما فرستاده شده' ,'info')
    except:
        code = random.randint(1000,9999)
        email(email = email_code,code = str(code))
        email_otp = EmailOtp.objects.create(code = code ,email = email_code)
    return redirect('accounts:verify')
#
#
#
class VerifyView(View):
    form_class = CodeForm
    template_name = 'accounts/verify.html'
    def get(self ,request):
        context = {
            'form': self.form_class
        }
        return render(request ,self.template_name ,context)
    def post(self ,request):
        form = self.form_class(request.POST)
        if form.is_valid():
            cd = form.cleaned_data
            session = request.session['sign_up']
            user_email = session['email']
            otp_code = EmailOtp.objects.get(email =user_email)
            code_instance = cd['code']
            if otp_code.code == int(code_instance):
                user = CustomUser.objects.create_user(
                    username= session['username'],
                    first_name = session['first_name'],
                    last_name = session['last_name'],
                    email= session['email'],
                    password= session['password'],
                )
                user.save()
                login(request ,user)
                messages.success(request ,'حساب کاربری شما با موفقیت ساخته شد' ,'success')
                return redirect('home:index')
            else:
               messages.success(request ,'حساب کاربری شما با موفقیت ساخته شد' ,'success')
               return redirect('accounts:verify') 
        return redirect('accounts:verify')
#
#
#
class LoginView(View):
    form_class = LoginForm
    template_name = 'accounts/login.html'
    def setup(self, request, *args, **kwargs):
        self.next = request.GET.get('next')
        return super().setup(request, *args, **kwargs)
    def dispatch(self, request, *args, **kwargs):
        if request.user.is_authenticated:
            messages.success(request ,'شما قبلا وارد حساب خود شدید' ,'info')
            return redirect('home:index')
        return super().dispatch(request, *args, **kwargs)
    def get(self ,request):
        context = {'form':self.form_class}
        return render(request ,self.template_name ,context)
    def post(self ,request):
        form = self.form_class(request.POST)
        if form.is_valid():
            cd = form.cleaned_data
            user = authenticate(request ,email=cd['email'] ,password=cd['password'])
            print (user)
            if user is not None:
                login(request ,user)
                messages.success(request ,'شما با موفقیت وارد حساب خود شدید' ,'success')
                print(self.next)
                if self.next:
                    return redirect(self.next)
                return redirect('home:index')
        return redirect('accounts:login')
#
#
#
class LogoutView(LoginRequiredMixin ,View):
    def get(self ,request):
        logout(request)
        return redirect('home:index')
#   
class PasswordResetView(auth_views.PasswordResetView):
    template_name = 'accounts/password_reset/reset_view.html'
    success_url = reverse_lazy('accounts:password_reset_done')
    email_template_name = 'accounts/password_reset/email.html'
#
class PasswordRestDoneView(auth_views.PasswordResetDoneView):
    template_name = 'accounts/password_reset/done.html'
#
class PasswordRestConfirmView(auth_views.PasswordResetConfirmView):
    template_name = 'accounts/password_reset/confirm.html'
    success_url = reverse_lazy('accounts:password_reset_complete')
#    
class PasswordRestCompleteView(auth_views.PasswordResetCompleteView):
    template_name = 'accounts/password_reset/complete.html'
#
# 
#    
class ManageProfileView(LoginRequiredMixin ,View):
    form_class = ProfileForm
    template_name = 'accounts/profile/manage_profile.html'
    def setup(self, request, *args, **kwargs):
        self.user = request.user
        self.profile = CustomUserProfile.objects.get(user=self.user)
        return super().setup(request, *args, **kwargs)
    def get(self ,request):
        context = {
            'user':self.user,
            'profile':self.profile,
            'form':self.form_class
            }
        return render(request ,self.template_name ,context)
    def post(self ,request):
        form = self.form_class(request.POST ,request.FILES)
        if form.is_valid():
            cd = form.cleaned_data
            
            self.user.first_name = cd['first_name']
            if cd['age'] is not None:
                self.profile.age = cd['age']
            if cd['language'] is not None:
                self.profile.language = cd['language']
            if cd['sex'] is not None:
                self.profile.sex = cd['sex']
            if request.FILES.get('user_photo' ,False):
                self.profile.user_photo = cd['user_photo']
            self.user.save()
            self.profile.save()
            return redirect('accounts:manage_profile')
        context = {
            'user':self.user,
            'profile':self.profile,
            'form':self.form_class
            }
        return render(request ,self.template_name ,context)            
#
#
#
class SettingProfileView(LoginRequiredMixin ,View):
    template_name = 'accounts/profile/settings.html'
    def setup(self, request, *args, **kwargs):
        self.user = request.user
        self.profile = CustomUserProfile.objects.get(user=self.user)
        return super().setup(request, *args, **kwargs)
    def get(self ,request):
        context = {
            'user':self.user,
            'profile':self.profile,
            }
        return render(request ,self.template_name ,context)
#
# 
#   
class UpdateProfileView(LoginRequiredMixin ,View):
    form_class = ProfileSettingForm
    template_name = 'accounts/profile/update_profile.html'
    def setup(self, request, *args, **kwargs):
        self.user = request.user
        self.profile = CustomUserProfile.objects.get(user=self.user)
        return super().setup(request, *args, **kwargs)
    def get(self ,request):
        self.form_class.biography = self.profile.biography
        self.form_class.address = self.profile.address
        context = {
            'user':self.user,
            'profile':self.profile,
            'form':self.form_class,
            }
        return render(request ,self.template_name ,context)
    def post(self ,request):
        form = self.form_class(request.POST)
        if form.is_valid():
            cd = form.cleaned_data
            if cd['biography'] is not None:
                self.profile.biography = cd['biography']
            if cd['address'] is not None:
                self.profile.address = cd['address']
            self.profile.save()
            return redirect('accounts:settings')
        context = {
            'user':self.user,
            'profile':self.profile,
            'form':self.form_class
            }
        return render(request ,self.template_name ,context)
#
# 
#
#
#
class ChangeEmailView(LoginRequiredMixin ,View):
    form_class = ChangeEmailForm
    template_name = 'accounts/settings/change_email.html'
    def setup(self, request, *args, **kwargs):
        self.user = request.user
        self.profile = CustomUserProfile.objects.get(user=self.user)
        return super().setup(request, *args, **kwargs)
    def get(self ,request):
        context = {
            'user':self.user,
            'profile':self.profile,
            'form':self.form_class,
            }
        return render(request ,self.template_name ,context)
    def post(self ,request):
        form = self.form_class(request.POST)
        if form.is_valid():
            cd = form.cleaned_data
            request.session['change_email'] = {
                'email1': str(self.user.email),
                'email2': cd['email'],
            }
            return redirect('accounts:send_change_code')
        context = {
            'user':self.user,
            'profile':self.profile,
            'form':self.form_class
            }
        return render(request ,self.template_name ,context)
#
#    
class SendChangeCode(LoginRequiredMixin,View):
    def get(self ,request):
        session = request.session['change_email']
        email_code1 = str(session['email1'])
        email_code2 = str(session['email2'])
        async_task(my_task)
        time.sleep(2)
        try:
            otp_code1= EmailOtp.objects.get(email = str(email_code1))
            messages.success(request ,'کد تایید قبلا برای شما فرستاده شده' ,'info')
        except:
            code1 = random.randint(1000,9999)
            email(email = str(email_code1),code = str(code1))
            email_otp1 = EmailOtp.objects.create(code = code1 ,email = str(email_code1))
            print('1:'+str(code1))
        try:
            otp_code2= EmailOtp.objects.get(email = str(email_code2))
            messages.success(request ,'کد تایید قبلا برای شما فرستاده شده' ,'info')
        except:
            code2 = random.randint(1000,9999)
            email(email = str(email_code2),code = str(code2))
            email_otp2 = EmailOtp.objects.create(code = code2 ,email = str(email_code2))
            print('2:'+str(code2))
        return redirect('accounts:verify_email')
#
#
#
class VerifyChangeEmailView(LoginRequiredMixin ,View):
    form_class = CodeChangeForm
    template_name = 'accounts/settings/verify_email.html'
    def setup(self, request, *args, **kwargs):
        self.user = request.user
        self.profile = CustomUserProfile.objects.get(user=self.user)
        self.session = request.session['change_email']
        return super().setup(request, *args, **kwargs)
    def get(self ,request):
        context = {
            'user':self.user,
            'profile':self.profile,
            'form':self.form_class,
            'session':self.session,
            }
        return render(request ,self.template_name ,context)
    def post(self ,request):
        form = self.form_class(request.POST)
        if form.is_valid():
            cd = form.cleaned_data
            user_email = str(self.user.email)
            new_email = str(self.session['email2'])
            otp_code1 = EmailOtp.objects.get(email =user_email)
            otp_code2 = EmailOtp.objects.get(email =new_email)
            code_instance1 = cd['code1']
            code_instance2 = cd['code2']
            if otp_code2.code == int(code_instance2) and otp_code1.code == int(code_instance1):
                self.user.email = self.session['email2']
                self.user.save()
                EmailOtp.objects.get(email =user_email).delete()
                EmailOtp.objects.get(email =new_email).delete()
                messages.success(request ,'ایمیل شما با موفقیت تغییر کرد' ,'success')
                return redirect('accounts:settings')
            else:
               messages.success(request ,'کد های وارد شده نامعتبر است' ,'success')
               return redirect('accounts:verify_email') 
        return redirect('accounts:verify_email')
#
#
#