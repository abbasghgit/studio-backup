from django.urls import path
from .views import *
app_name = 'accounts'
urlpatterns = [
########
    path('signup/' , SignUpView.as_view() , name="sign_up"),
    path('login/' , LoginView.as_view() , name="login"),
    path('logout/' , LogoutView.as_view() , name="logout"),
    path('send_code/' , SendCode , name="send_code"),
    path('verify/' , VerifyView.as_view() , name="verify"),
########
    path('reset/' , PasswordResetView.as_view() , name="password_reset"),
    path('rest/done' , PasswordRestDoneView.as_view() , name="password_reset_done"),
    path('complete/' , PasswordRestCompleteView.as_view() , name="password_reset_complete"),
    path('confirm/<uidb64>/<token>/' , PasswordRestConfirmView.as_view() , name="password_reset_confirm"),
########
    path('manage-profile/' , ManageProfileView.as_view() , name="manage_profile"),
    path('settings/' , SettingProfileView.as_view() , name="settings"),
    path('update-profile/' , UpdateProfileView.as_view() , name="update_profile"),
    path('change-email/' , ChangeEmailView.as_view() , name="change_email"),
    path('send-change-code/' , SendChangeCode.as_view() , name="send_change_code"),
    path('verify-email/' , VerifyChangeEmailView.as_view() , name="verify_email"),
]