from django.db import models
from django.contrib.auth.models import AbstractUser
from .managers import CustomUserManager as managers
import datetime
# Create your models here.
#
#
class CustomUser(AbstractUser):
    ROLES = {
        ('user','user'),
        ('basicuser' ,'basicuser'),
        ('vipuser' ,'vipuser'),
        ('admin' ,'admin'),
        ('superuser' ,'superuser')
    }
    username = models.CharField(max_length=38 ,unique=True)
    first_name = models.CharField(max_length=55)
    last_name = models.CharField(max_length=65)
    email = models.EmailField(max_length=150 , unique=True)
    password = models.CharField(max_length=50)
    role = models.CharField(choices=ROLES ,max_length=50)
#   
    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = ('username' , 'password',)
#
    objects = managers()

#
    def __str__(self):
        return f'نام کاربری :  {self.username}  دسته : {self.role} '
#
#
#
def upload_userphoto_to(instance ,filename):
    return "images/accounts/user-photo/{0}/{1}".format(instance.user.username ,filename)
class CustomUserProfile(models.Model):
    LANGUAGE = {
        ('پارسی' , 'پارسی'),
        ('english' , 'انگلیسی'),
    }
    SEX = {
        ('زن' , 'female'),
        ('مرد' , 'male'),
        ('خنثی' , 'trans'),
    }
    user = models.ForeignKey(CustomUser ,on_delete=models.CASCADE ,related_name='profle')
    user_photo = models.ImageField(upload_to =upload_userphoto_to ,blank=True,null=True)
    age = models.SmallIntegerField(blank=True,null=True)
    biography = models.TextField(max_length=350 ,blank=True,null=True)
    address =  models.TextField(max_length=350 ,blank=True,null=True)
    language = models.CharField(choices=LANGUAGE, max_length=50 ,blank=True,null=True ,default='پارسی')
    sex = models.CharField(choices=SEX , max_length=50 ,blank=True,null=True)
#
#
#
class EmailOtp(models.Model):
    code = models.IntegerField()
    email = models.EmailField()
    create = models.DateTimeField(default=datetime.datetime.today())

    def __str__(self):
        return self.email
#
#
####################################
#
#
class Module(models.Model):
    name = models.CharField(max_length=50)

    def __str__(self):
        return self.name
#
#
class Permission(models.Model):
    name = models.CharField(max_length=50)
    module = models.ForeignKey(
        Module,
        on_delete=models.CASCADE
    )
    def __str__(self):
        return f'{self.name} - {self.module}'
#
#
class Role(models.Model):
    name = models.CharField(max_length=80)
    permissions = models.ManyToManyField(Permission)

    def __str__(self):
        return f'{self.name} - {self.permissions}'
#
#
class UserRole(models.Model):
    user = models.OneToOneField(
        CustomUser,
        on_delete=models.CASCADE,
    )
    role = models.ForeignKey(
        Role,
        on_delete=models.SET_NULL,
        blank=True,
        null=True,
    )
    def __str__(self):
        return f'{self.user.username} - {self.role}'
#
#
#