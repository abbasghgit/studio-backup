from django.shortcuts import render ,get_object_or_404
from django.views import View
from django.contrib import messages
from django.utils.decorators import method_decorator
from accounts.decorators import has_permission
from movies.models import Movie ,Category
# Create your views here.

class HomeView(View):
    template_name = 'home/index.html'
    def get(self ,request):
        search = None
        if request.GET.get('search'):
            search = Movie.objects.filter(name__contains = request.GET['search'])
        slider = Movie.objects.filter(year__gte = 2022,imdb_rating__gte = 6.0)[:5]
        top_ten = Movie.objects.filter(imdb_rating__gte = 7.0).order_by('year')[:10]
        movie_order_by_year = Movie.objects.filter(category__name = 'ایران',year__gte = 2023)[:7]
        movie_order_by_imdb = Movie.objects.filter(category__name = 'ایران',imdb_rating__gte = 7.0)[:7]
        movie_order_by_age = Movie.objects.filter(category__name = 'ایران',age__gte =12)[:7]
        movie_order_by_duration = Movie.objects.filter(duration__gte =182)[:7]
        movie_order_by_love = Movie.objects.filter(year__gte = 1)[:7]
        paralex =  Movie.objects.filter(age__gte =12)[:1]
        context = {
            'sliders' :slider,
            'search':search,
            'movie_order_by_year': movie_order_by_year,
            'movie_order_by_imdb': movie_order_by_imdb,
            'top_ten' : top_ten,
            'movie_order_by_age': movie_order_by_age,
            'movie_order_by_duration':movie_order_by_duration,
            'movie_order_by_love':movie_order_by_love,
            'paralexs':paralex,
        }
        return render(request , self.template_name ,context)
#?