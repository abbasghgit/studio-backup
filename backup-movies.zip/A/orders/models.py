from django.db import models
from accounts.models import CustomUser
import datetime
# Create your models here.
class PricePlan(models.Model):
    basic_price = models.IntegerField(verbose_name="قیمت طرح پایه")
    vip_price = models.IntegerField(verbose_name="قیمت طرح ویژه")
    others_price = models.IntegerField(verbose_name="قیمت دیگر")
    create = models.DateTimeField(default=datetime.datetime.today())
#
    def __str__(self):
        return f"{self.basic_price} - {self.vip_price} - {self.others_price}"

class Subscription(models.Model):
    user = models.ForeignKey(
        CustomUser ,
        on_delete= models.CASCADE,
        related_name='subscriptions',
    )
    price = models.IntegerField(blank=True ,null=True)
    paid = models.BooleanField(default=False)
    is_vip = models.BooleanField(default=False)
    available = models.BooleanField(default=True)
    create = models.DateTimeField(default=datetime.datetime.today())
    update = models.DateTimeField(default=None,null=True,blank=True)
#
    def __str__(self):
        return self.user.username