from django.shortcuts import render ,redirect ,get_object_or_404
from django.views import View
from django.contrib.auth.mixins import LoginRequiredMixin
from django.http import HttpResponse
from .models import *
from .zarinpal import ZarinPal
import datetime
# Create your views here.
class PriceView(LoginRequiredMixin ,View):
    template_name = 'orders/price.html'
    def get(self ,request):
        pricing = None
        pricing_plane = PricePlan.objects.order_by('create')[:1]
        for item in pricing_plane:
            pricing = item
        context = {
            'pricing': pricing,
        }
        return render(request ,self.template_name ,context)
    

class CreateSubscriptionView(LoginRequiredMixin ,View):
    def get(self ,request ,*args ,**kwargs):
        subscription = Subscription.objects.create(user = request.user)
        price_plan = get_object_or_404(PricePlan ,id =kwargs['plan_id'])
        myplan = kwargs['myplan']
        if myplan == 'one':
            price = price_plan.basic_price
            subscription.is_vip = False
            subscription.price = price
            subscription.save()
        elif myplan == 'two':
            price = price_plan.vip_price
            subscription.is_vip = True
            subscription.price = price
            subscription.save()
        else:
            return redirect('orders:price')
        return redirect('orders:request' ,subscription.id)

# درگاه زرین پال


pay = ZarinPal(merchant='5096280d-21ec-4e95-86dd-1d4c0eb34ada', call_back_url="http://127.0.0.1:8000/orders/verify/")


def send_request(request ,*args ,**kwargs):
    subscription = get_object_or_404(Subscription ,id=kwargs['sub_id'])
    amount = subscription.price
    request.session['bank_information'] = {
        'sub_id':str(kwargs['sub_id']),
    }
    
    # email and mobile is optimal
    response = pay.send_request(amount=amount, description='توضیحات مربوط به پرداخت',sub_id=subscription.id,email=request.user.email)
    if response.get('error_code') is None:
        # redirect object
        return response
    else:
        return HttpResponse(f'Error code: {response.get("error_code")}, Error Message: {response.get("message")}')


def verify(request ,*args ,**kwargs):
    template_name = 'orders/verify.html'
    subscription = get_object_or_404(Subscription ,id=kwargs['sub_id'])
    amount = subscription.price
    response = pay.verify(request=request, amount=amount)

    if response.get("transaction"):
        if response.get("pay"):
            subscription.paid = True
            subscription.available = True
            subscription.create = datetime.datetime.today()
            subscription.save()
            return render(request ,template_name)
        else:
            return HttpResponse('این تراکنش با موفقیت انجام شده است و الان دوباره verify شده است')
    else:
        if response.get("status") == "ok":
            return HttpResponse(f'Error code: {response.get("error_code")}, Error Message: {response.get("message")}')
        elif response.get("status") == "cancel":
            return HttpResponse(f'تراکنش ناموفق بوده است یا توسط کاربر لغو شده است'
                                f'Error Message: {response.get("message")}')
        
        