from django.urls import path
from .views import *
app_name = 'orders'
urlpatterns = [
    path('price/' ,PriceView.as_view() ,name ='price'),
    path('subscription/<int:plan_id>/<str:myplan>/' ,CreateSubscriptionView.as_view() ,name ='create_sub'),
    path('request/<int:sub_id>/' ,send_request ,name ='request'),
    path('verify/<int:sub_id>/' ,verify ,name ='verify'),
]