from django.db.models.signals import post_save
from django.dispatch import receiver
from .models import Subscription

@receiver(post_save ,sender=Subscription)
def update_basicuser(sender,instance ,created ,**kwargs):
    if not created:
        if instance.paid and instance.available and instance.is_vip:
            user = instance.user
            user.role='vipuser'
            user.save()
        elif instance.paid and instance.available:
            user = instance.user
            user.role='basicuser'
            user.save()            
        else:
            user = instance.user
            user.role='user'
            user.save()

@receiver(post_save ,sender=Subscription)
def create_basicuser(sender,instance ,created ,**kwargs):
    if created:
        if instance.paid and instance.available and instance.is_vip:
            user = instance.user
            user.role='vipuser'
            user.save()
        elif instance.paid and instance.available:
            user = instance.user
            user.role='basicuser'
            user.save()            
        else:
            user = instance.user
            user.role='user'
            user.save()



