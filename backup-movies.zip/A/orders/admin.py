from django.contrib import admin
from .models import PricePlan, Subscription
# Register your models here.
admin.site.register(PricePlan)
admin.site.register(Subscription)
